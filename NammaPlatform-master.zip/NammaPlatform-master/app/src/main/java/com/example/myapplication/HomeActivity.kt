package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class HomeActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        val btnStart = findViewById<Button>(R.id.btnStart)

        btnStart.setOnClickListener {

            // OPEN STATION LIST PAGE
            val intent = Intent(this, StationListActivity::class.java)

            startActivity(intent)
        }
    }
}